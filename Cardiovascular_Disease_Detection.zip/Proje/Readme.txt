In this project I have used historical data about disease and try to define any potential illness according to those criteria.
According my Machine Learning result, when we insert any value to each features using API and request, we can get information that is that person
is ill or not