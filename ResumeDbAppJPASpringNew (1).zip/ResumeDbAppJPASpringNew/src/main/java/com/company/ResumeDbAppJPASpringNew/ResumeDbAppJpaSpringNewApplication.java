package com.company.ResumeDbAppJPASpringNew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeDbAppJpaSpringNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumeDbAppJpaSpringNewApplication.class, args);
	}

}
