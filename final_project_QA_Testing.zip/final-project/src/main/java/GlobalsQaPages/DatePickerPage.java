package GlobalsQaPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DatePickerPage extends GlobalsQaBasePage{
    public DatePickerPage(WebDriver driver) {
        super(driver);
    }
    @FindBy (xpath = "//*[@id=\"menu-item-2827\"]/a/span")
    public WebElement datePicker;

    @FindBy (css= "[id = 'datepicker']")
    public WebElement calendarBox;

    @FindBy (css= "[class='ui-datepicker-calendar']")
    public WebElement calendar;

    @FindBy (css= "[class='ui-icon ui-icon-circle-triangle-e']")
    public WebElement calendarNextButton;

    @FindBy (css = "[class='demo-frame lazyloaded']")
    public WebElement iFrameDatePicker;

    @FindBy (xpath = "//*[@id=\"datepicker\"]")
    public WebElement boxToCheck;

}
