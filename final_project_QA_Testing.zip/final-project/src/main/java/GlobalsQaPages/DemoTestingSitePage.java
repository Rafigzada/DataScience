package GlobalsQaPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

import static org.openqa.selenium.support.How.CSS;

public class DemoTestingSitePage extends GlobalsQaBasePage{
    public DemoTestingSitePage(WebDriver driver) {
        super(driver);
    }


    @FindBy(xpath = "//*[@id=\"post-2715\"]/div[2]/div/div/div[2]/div[1]/ul/li" )
    public List<WebElement> column1;

    @FindBy(xpath = "//*[@id=\"post-2715\"]/div[2]/div/div/div[2]/div[2]/ul/li" )
    public List<WebElement> column2;

    @FindBy(xpath = "//*[@id=\"post-2715\"]/div[2]/div/div/div[2]/div[3]/ul/li" )
    public List<WebElement> column3;


}
