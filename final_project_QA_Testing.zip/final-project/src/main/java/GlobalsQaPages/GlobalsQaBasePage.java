package GlobalsQaPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GlobalsQaBasePage {
    public GlobalsQaBasePage(WebDriver driver){
        PageFactory.initElements(driver,this);
    }
    @FindBy( xpath = "//*[@id=\"menu-item-2822\"]/a" )
    public WebElement testersHub;

    @FindBy (xpath = "//*[@id=\"menu-item-2823\"]/a/span")
    public WebElement demoTestingSite;

}
