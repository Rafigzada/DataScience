package GlobalsQaPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProgressBarPage extends GlobalsQaBasePage {
    public ProgressBarPage(WebDriver driver) {
        super(driver);
    }


   @FindBy(xpath = "//*[@id=\"menu-item-2832\"]/a/span")
   public WebElement progressBar;

   @FindBy( css = "[ id ='downloadButton'] ")
   public WebElement downloadButton;

   @FindBy (css = ".demo-frame.lazyloaded")
   public WebElement iFrameDownloading;

   @FindBy (css = "[class='ui-progressbar-value ui-corner-left ui-widget-header ui-progressbar-complete ui-corner-right']")
   public  WebElement completed;

   @FindBy (css = "[class='demo-description']")
    public  WebElement description;

}
