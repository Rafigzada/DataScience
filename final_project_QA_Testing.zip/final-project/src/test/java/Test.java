import GlobalsQaPages.DatePickerPage;
import GlobalsQaPages.DemoTestingSitePage;
import GlobalsQaPages.ProgressBarPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class Test {
    private WebDriver d;

    @BeforeTest
    public void beforeTest(){
        d = new ChromeDriver();
        d.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        d.manage().window().maximize();
    }
    @AfterTest
    public void afterTest(){
        d.quit();
    }

    /*
    Test 1
    1.Navigate to “TESTER’S HUB”-> “Demo Testing Site”menu item
    2.Verify that number of items in each column are equal 6.
     */

    @org.testng.annotations.Test
    public void verificationOfSixElements() throws InterruptedException{
        d.get("https://www.globalsqa.com/");
        DemoTestingSitePage demoTestingSitePage = new DemoTestingSitePage(d);
        navigateToDemoTestingSite(d, demoTestingSitePage.testersHub, demoTestingSitePage.demoTestingSite);

        var itemsInColumn1 = demoTestingSitePage.column1;
        var itemsInColumn2 = demoTestingSitePage.column2;
        var itemsInColumn3 = demoTestingSitePage.column3;

        var expected = 6;
        var actual = 0;
        if(itemsInColumn1.size() == 7 && itemsInColumn2.size() == 7 && itemsInColumn3.size()== 7){
            actual = 6;
        }


        Assert.assertTrue(String.format("The number of items in each column is not equal to %s" + ".  Actual number is %s",expected,actual), actual==expected);
    }
    @org.testng.annotations.Test
    public void navigateToDemoTestingSite(WebDriver driver, WebElement testersHub, WebElement demoTestingSite){
        Actions action = new Actions(d);
        action.moveToElement(testersHub).perform();

        WebDriverWait wait = new WebDriverWait(d,10);
        wait.until(ExpectedConditions.visibilityOf(demoTestingSite));
        demoTestingSite.click();
    }

    /*
    Test 2
    1.Navigate to “TESTER’S HUB” -> “Demo Testing Site” -> “Date picker” menu item.
    2.Choose current day (for example, 17) for the next month via calendar.
    3.Verify that date is displayed in format “mm/dd/yyyy” (for example, 07/17/2021).
     */

    @org.testng.annotations.Test
    public void navigateToDatePicker(WebDriver driver, WebElement testersHub, WebElement demoTestingSite, WebElement datePicker){
        Actions action = new Actions(d);
        action.moveToElement(testersHub).perform();

        WebDriverWait wait = new WebDriverWait(d,10);
        wait.until(ExpectedConditions.visibilityOf(demoTestingSite));

        action.moveToElement(demoTestingSite).perform();

        wait.until(ExpectedConditions.visibilityOf(datePicker));
        datePicker.click();


    }

    @org.testng.annotations.Test
    public void clickCurrentDayAndVerify() throws InterruptedException{
        //Arrange
        d.get("https://www.globalsqa.com/");
        DatePickerPage datePickerPage = new DatePickerPage(d);

        //Act
        navigateToDatePicker(d, datePickerPage.testersHub, datePickerPage.demoTestingSite, datePickerPage.datePicker);
        d.switchTo().frame(datePickerPage.iFrameDatePicker);

        WebDriverWait wait = new WebDriverWait(d,15);
        wait.until(ExpectedConditions.visibilityOf(datePickerPage.calendarBox));

        datePickerPage.calendarBox.click();
        wait.until(ExpectedConditions.visibilityOf(datePickerPage.calendarNextButton));
        datePickerPage.calendarNextButton.click();


        WebElement table = wait.until(ExpectedConditions.visibilityOf(datePickerPage.calendar));
        List<WebElement> columns = table.findElements(By.tagName("td"));

        DateClass.clickGivenDay(columns, DateClass.getCurrentDay());

        Thread.sleep(2000);

        //Assert

        var actual =datePickerPage.boxToCheck.getAttribute("value");

        String dateExpected =DateClass.getNextMonth()  + "/" +DateClass.getCurrentDay()+ "/" +DateClass.getCurrentYear() ;


        System.out.println("Expected: "+dateExpected);
        System.out.println("Actual: "+actual);

        Assert.assertEquals(actual,dateExpected);



    }


    public static class DateClass {

        public static String getCurrentDay() {
            Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
            int currentDay = calendar.get(Calendar.DAY_OF_MONTH);


            String currentDayStr = Integer.toString(currentDay);
            if(currentDay<10){
                currentDayStr="0"+currentDayStr;
            }
            return currentDayStr;

        }
            public static String getNextMonth() {
            Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
            int nextMonth = calendar.get(Calendar.MONTH);

            String nextMonthStr = Integer.toString(nextMonth+2);
                if(nextMonth<10){
                    nextMonthStr="0"+nextMonthStr;
                }
            return nextMonthStr;
        }
        public static String getCurrentYear() {
            Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
            int currentYear = calendar.get(Calendar.YEAR);

            String currentYearStr = Integer.toString(currentYear);
            return currentYearStr;
        }


        //Click to given day
        public static void clickGivenDay(List<WebElement> elements, String day) {

            elements.stream().filter(element -> element.getText().contains(day)).findFirst().ifPresent(WebElement::click);


        }
    }


    /*
    Test 3 1.Navigate to “TESTER’S HUB” ->v  “Demo Testing Site” -> “ProgressBar” menu item.
    2.Click “Start Download” button.
    3.Wait for downloading.
    4.Verify that downloading is finished.
     */

    @org.testng.annotations.Test
    public void verifyDownloadingIsFinished(){
        // Arrange
        ProgressBarPage progressBarPage = new ProgressBarPage(d);
        d.get("https://www.globalsqa.com/");


        // Act
        navigateToProgressBar(d, progressBarPage.testersHub, progressBarPage.demoTestingSite, progressBarPage.progressBar);

        d.switchTo().frame(progressBarPage.iFrameDownloading);

        WebDriverWait wait = new WebDriverWait(d,15);
        wait.until(ExpectedConditions.visibilityOf(progressBarPage.description));
        progressBarPage.downloadButton.click();



        wait.until(ExpectedConditions.visibilityOf(progressBarPage.completed));


        // Assert
        var expected_percentage = " 100%";
        var actual_percentage = progressBarPage.completed.getAttribute("style").split(";")[0].split(":")[1];




        var actual = progressBarPage.completed.getAttribute("width");
        org.testng.Assert.assertEquals(actual_percentage,expected_percentage);




    }

    @org.testng.annotations.Test
    public void navigateToProgressBar(WebDriver driver, WebElement testersHub, WebElement demoTestingSite, WebElement progressBar){
        Actions action = new Actions(d);
        action.moveToElement(testersHub).perform();

        WebDriverWait wait = new WebDriverWait(d,10);
        wait.until(ExpectedConditions.visibilityOf(demoTestingSite));

        action.moveToElement(demoTestingSite).perform();

        wait.until(ExpectedConditions.visibilityOf(progressBar));
        progressBar.click();

    }
}
